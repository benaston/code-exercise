namespace Tesco.Code
{
    public interface ILogger
    {
        void Log(string message);
    }
}