﻿namespace Tesco.Code
{
    public class AuthorisationRequest
    {
    }
}
