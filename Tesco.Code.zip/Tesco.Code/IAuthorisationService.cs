namespace Tesco.Code
{
    public interface IAuthorisationService
    {
        void Authorise(AuthorisationRequest request);
    }
}