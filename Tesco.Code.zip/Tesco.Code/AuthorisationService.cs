namespace Tesco.Code
{
    public class AuthorisationService : IAuthorisationService
    {
        public void Authorise(AuthorisationRequest request)
        {
            //Authorisation code (NOTE: please see LogAverageExecutionTimeDecorator for the instrumentation)
        }
    }
}